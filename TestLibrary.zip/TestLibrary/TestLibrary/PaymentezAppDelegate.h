//
//  PaymentezAppDelegate.h
//  TestLibrary
//
//  Created by Gustavo Sotelo on 25/03/14.
//  Copyright (c) 2014 Paymentez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentezAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
