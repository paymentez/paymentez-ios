//
//  PaymentezAddViewController.m
//  TestLibrary
//
//  Created by Gustavo Sotelo on 26/03/14.
//  Copyright (c) 2014 Paymentez. All rights reserved.
//

#import "PaymentezAddViewController.h"
#import "PaymentezCCSDK.h"

@interface PaymentezAddViewController ()

@end

@implementation PaymentezAddViewController
@synthesize webView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    PaymentezCCSDK *apiManager = [PaymentezCCSDK sdkManagerWithDevConf:true withAppCode:@"ST-MX" andAppKey:@"vgVfq0kLZveGIdD9ljGjPtt6ieYtIQ" digestUsername:@"PREPAID" digestPassword:@"Ere68ttPklFTn89xZIhFYcqC5X8HX3Ob5qgbEkfjNfCLkud3wY"];
    
    
    [apiManager addCard:@"1234" email:@"martin.mucito@gmail.com" completionHandler:^(NSDictionary *response, NSError *error) {
        NSLog(@"response:%@",response);
        NSLog(@"error:%@",error);
        if(!error)
        {
            NSString *url = (NSString*)[response objectForKey:@"url"];
            NSLog(@"%@", url);
            NSURL *nsUrl = [NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            NSURLRequest* request = [NSURLRequest requestWithURL:nsUrl cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:30];
            
            [self.webView loadRequest:request];
            
        }
    }];

    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
