//
//  PaymentezListTableViewController.h
//  TestLibrary
//
//  Created by Gustavo Sotelo on 26/03/14.
//  Copyright (c) 2014 Paymentez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentezListTableViewController : UITableViewController<UITableViewDataSource, UITableViewDelegate>

@end
