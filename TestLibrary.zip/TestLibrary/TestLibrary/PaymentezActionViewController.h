//
//  PaymentezActionViewController.h
//  TestLibrary
//
//  Created by Gustavo Sotelo on 27/03/14.
//  Copyright (c) 2014 Paymentez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentezActionViewController : UIViewController

@property (nonatomic,strong) NSString *card_reference;
@end
