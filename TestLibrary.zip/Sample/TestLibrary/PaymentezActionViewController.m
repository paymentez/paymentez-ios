//
//  PaymentezActionViewController.m
//  TestLibrary
//
//  Created by Gustavo Sotelo on 27/03/14.
//  Copyright (c) 2014 Paymentez. All rights reserved.
//

#import "PaymentezActionViewController.h"
#import "PaymentezCCSDK.h"

@interface PaymentezActionViewController ()

@end

@implementation PaymentezActionViewController
@synthesize card_reference;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)debitAction:(id)sender
{
    
    PaymentezCCSDK *apiManager = [PaymentezCCSDK sdkManagerWithDevConf:true withAppCode:@"ST-MX" andAppKey:@"vgVfq0kLZveGIdD9ljGjPtt6ieYtIQ" digestUsername:@"PREPAID" digestPassword:@"Ere68ttPklFTn89xZIhFYcqC5X8HX3Ob5qgbEkfjNfCLkud3wY"];
    [apiManager debitCard:self.card_reference amount:[NSNumber numberWithFloat:10.0] description:@"test" devReference:@"1234567" userId:@"1234" email:@"martin.mucito@gmail.com" completionHandler:^(NSDictionary *response, NSError *error) {
        NSLog(@"response:%@",response);
        NSLog(@"error:%@",error);
        
        if(!error)
        {
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Transaction Complete"
                                                            message:@"Debit of 10 successful"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
            
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                            message:[NSString stringWithFormat:@"%@",error ]
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
        }
    }];
    }
-(IBAction)deleteAction:(id)sender
{
    PaymentezCCSDK *apiManager = [PaymentezCCSDK sdkManagerWithDevConf:true withAppCode:@"ST-MX" andAppKey:@"vgVfq0kLZveGIdD9ljGjPtt6ieYtIQ" digestUsername:@"PREPAID" digestPassword:@"Ere68ttPklFTn89xZIhFYcqC5X8HX3Ob5qgbEkfjNfCLkud3wY"];
    
    
    
    [apiManager deleteCard:self.card_reference userId:@"1234" completionHandler:^(NSDictionary *response, NSError *error) {
        NSLog(@"response:%@",response);
        NSLog(@"error:%@",error);
        
        if(!error)
        {
            
            [self.navigationController popViewControllerAnimated:YES];
            
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                            message:[NSString stringWithFormat:@"%@",error ]
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
        }
    }];

    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
