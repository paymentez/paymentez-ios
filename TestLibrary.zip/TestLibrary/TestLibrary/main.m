//
//  main.m
//  TestLibrary
//
//  Created by Gustavo Sotelo on 25/03/14.
//  Copyright (c) 2014 Paymentez. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PaymentezAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PaymentezAppDelegate class]));
    }
}
