//
//  PaymentezAddViewController.h
//  TestLibrary
//
//  Created by Gustavo Sotelo on 26/03/14.
//  Copyright (c) 2014 Paymentez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentezAddViewController : UIViewController
@property (nonatomic, weak) IBOutlet UIWebView *webView;
@end
